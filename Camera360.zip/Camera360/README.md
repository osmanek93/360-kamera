# Kamera 360 (bağımsız)

MapControl 1.3.4 içindeki **Kamera 360** sekmesinin (Canlı önizleme, USB kayıt, araç içi otomatik kayıt, izleme ekranı) tek başına çalışan hali.
Kamera kodu orijinalden değiştirilmeden alındı; sadece küçük bir ana ekran + güç modu servisi eklendi.

- paket adı (applicationId): `com.camera360.standalone` (MapControl ile aynı cihazda yan yana durabilir)
- Yalnızca Desay SV ünitelerinde (`/dev/hab` olan) kamera görüntüsü verir.

## Derleme

**A) GitHub Actions (bilgisayara bir şey kurmadan):** projeyi yeni bir GitHub deposuna yükleyin →
Actions → "Build APK" → Run workflow → bitince "Camera360-apk" çıktısını indirin.

**B) Android Studio:** klasörü açın → Build > Build APK(s).
Gereksinimler: JDK 17, Android SDK 34, NDK + CMake 3.22.1.

## Kurulum (araç ünitesi)

    adb install -r app-release.apk
    adb shell pm grant com.camera360.standalone android.permission.CAMERA
    adb shell pm grant com.camera360.standalone android.permission.RECORD_AUDIO
    adb shell appops set com.camera360.standalone MANAGE_EXTERNAL_STORAGE allow
    adb shell dumpsys deviceidle whitelist +com.camera360.standalone
