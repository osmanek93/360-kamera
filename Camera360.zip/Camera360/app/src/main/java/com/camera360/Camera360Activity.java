package com.camera360;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.mapcontrol.ui.builder.Camera360TabBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * MapControl içindeki "Kamera 360" sekmesini tek başına gösteren ekran. Sekmenin kendisi
 * (Camera360TabBuilder) değiştirilmeden kullanılır; hız/vites bindirmesi DvrController
 * tarafından doğrudan araç verisinden okunur.
 */
public class Camera360Activity extends AppCompatActivity {
    private Camera360TabBuilder tab;
    private FrameLayout holder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        holder = new FrameLayout(this);
        holder.setBackgroundColor(ContextCompat.getColor(this, com.mapcontrol.R.color.surfaceCard));
        setContentView(holder, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        requestMissingPermissions();
        Camera360HostService.start(this);

        tab = new Camera360TabBuilder(this);
        tab.setWideListener(wide -> { /* tek ekran, ayrı bir üst çerçeve yok */ });
        attach(tab.getTabContent());
    }

    private void attach(View content) {
        holder.removeAllViews();
        if (content.getParent() instanceof ViewGroup) {
            ((ViewGroup) content.getParent()).removeView(content);
        }
        holder.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void requestMissingPermissions() {
        String[] wanted = {
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
        };
        List<String> missing = new ArrayList<>();
        for (String p : wanted) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                missing.add(p);
            }
        }
        if (!missing.isEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toArray(new String[0]), 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (tab != null) tab.onTabVisible();
    }

    @Override
    protected void onPause() {
        if (tab != null) tab.onTabHidden();
        super.onPause();
    }
}
