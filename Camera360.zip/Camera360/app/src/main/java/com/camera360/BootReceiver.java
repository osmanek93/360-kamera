package com.camera360;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Sistem açılışında güç modunu izleyen servisi başlatır (otomatik kayıt için). */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        Camera360HostService.start(context);
    }
}
