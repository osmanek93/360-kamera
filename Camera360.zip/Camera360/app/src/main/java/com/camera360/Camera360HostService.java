package com.camera360;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import com.desaysv.ivi.extra.project.carinfo.ReadOnlyID;
import com.desaysv.ivi.extra.project.carinfo.proxy.CarInfoProxy;
import com.desaysv.ivi.vdb.event.id.carinfo.VDEventCarInfo;
import com.mapcontrol.R;
import com.mapcontrol.dvr.DvrController;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * MapControlService'in kamerayla ilgili tek işini yapar: araç güç modunu (OFF/STANDBY/ON)
 * 2 sn'de bir okuyup DvrController.onPowerMode'a iletir. Böylece kontak açılınca otomatik
 * kayıt (ayarlandıysa) uygulama açık olmadan da başlar/durur.
 */
public class Camera360HostService extends Service {
    private static final String CHANNEL_ID = "camera360_host";
    private static final int NOTIF_ID = 3600;

    private ScheduledExecutorService scheduler;
    private int lastPowerMode = Integer.MIN_VALUE;

    public static void start(Context ctx) {
        Context app = ctx.getApplicationContext();
        Intent i = new Intent(app, Camera360HostService.class);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                app.startForegroundService(i);
            } else {
                app.startService(i);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID,
                    "Kamera 360", NotificationManager.IMPORTANCE_MIN));
        }
        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_mdi_camera)
                .setContentTitle("Kamera 360")
                .setContentText("Araç güç modu izleniyor")
                .setOngoing(true)
                .build();
        startForeground(NOTIF_ID, n);

        DvrController.get(this).start();

        try {
            CarInfoProxy.getInstance().init(getApplicationContext());
        } catch (Throwable ignored) {
        }
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(this::pollPowerMode, 0, 2, TimeUnit.SECONDS);
    }

    private void pollPowerMode() {
        try {
            CarInfoProxy proxy = CarInfoProxy.getInstance();
            if (!proxy.isServiceConnnected()) {
                try {
                    proxy.init(getApplicationContext());
                } catch (Throwable ignored) {
                }
                return;
            }
            int[] v = proxy.getItemValues(VDEventCarInfo.MODULE_READONLY_INFO,
                    ReadOnlyID.ID_SYSTEM_POWER_MODE);
            if (v == null || v.length == 0) return;
            int mode = v[0];
            if (mode != lastPowerMode) {
                lastPowerMode = mode;
                DvrController.get(this).onPowerMode(mode);
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (scheduler != null) scheduler.shutdownNow();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
